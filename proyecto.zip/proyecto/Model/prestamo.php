<?php

class prestamo{

  public $CNX;
  public $idPrestamo;
  public $fecha;
  public $nombres;
  public $apellidos;
  public $documento;
  public $carnet;
  public $equipo;
  public $imei;
  public $descripcion;
  public $estado;




  public function __construct(){
    try{
      $this->CNX = conexion::conectar();
    } catch (Exception $e) {
      die($e->getMessage());
    }
  }

  public function listar(){
    try {
      $query = "SELECT * FROM `prestamo` ORDER BY `idPrestamo` ASC";
      $smt = $this->CNX->prepare($query);
      $smt->execute();
      return $smt->fetchAll(PDO::FETCH_OBJ);
    } catch (Exception $e) {
      die($e->getMessage());
    }
  }

  
  public function cargarID($id){
    try {
      $query = "SELECT * FROM prestamo where idPrestamo=?";
      $smt = $this->CNX->prepare($query);
      $smt->execute(array($id));
      return $smt->fetch(PDO::FETCH_OBJ);
    } catch (Exception $e) {
      die($e->getMessage());
    }
  }

  public function delete($id){
    try {
      $query = "delete from prestamo where idPrestamo =?";
      $smt = $this->CNX->prepare($query);
      $smt->execute(array($id));
    } catch (\Exception $e) {
      die($e->getMessage());
    }


  }

  public function registrar(prestamo $data){
    try {
      $query = "Insert into prestamo (fecha,nombres,apellidos,documento,carnet,equipo,imei,descripcion,estado) values (?,?,?,?,?,?,?,?,?)";
      $this->CNX->prepare($query)->execute(array($data->fecha,$data->nombres,$data->apellidos,$data->documento,$data->carnet,$data->equipo,$data->imei,$data->descripcion,$data->estado));

    } catch (\Exception $e) {
      die($e->getMessage());
    }

  }

  public function actualizarDatos(prestamo $data){
    try {
      $query = "UPDATE prestamo set fecha=?,nombres=?,apellidos=?,documento=?,carnet=?,equipo=?,imei=?,descripcion=?,estado=?  WHERE idPrestamo=?";
      $this->CNX->prepare($query)->execute(array($data->fecha,$data->nombres,$data->apellidos,$data->documento,$data->carnet,$data->equipo,$data->imei,$data->descripcion,$data->estado,$data->idPrestamo));

    } catch (\Exception $e) {
      die($e->getMessage());
    }

  }

}
 ?>
