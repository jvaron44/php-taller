<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>Inicio</title>

  <link href="Resources/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="Resources/css/simple-sidebar.css" rel="stylesheet">
  <link href="Resources/fonts/simple-sidebar.css" rel="stylesheet">
  <link href="Resources/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
</head>

<body>
  <form>
  <div class="d-flex" id="wrapper">

    <!-- Menú -->
    <div class="bg-light border-right" id="sidebar-wrapper">
      <div class="sidebar-heading text-center">U.Préstamo</div>
      <div class="list-group list-group-flush">
        <a href="inicio.php" class="list-group-item list-group-item-action bg-light"><i class="fab fa-umbraco"></i>
          <b>Inicio</b>
        </a>
        <a href="prestamo.php" class="list-group-item list-group-item-action bg-light"><i class="fas fa-laptop"></i>
          <b>Préstamo</b>
        </a>
        <hr>
      </div>
    </div>
    <!-- /Menú-->

    <!-- Page Content -->
    <div id="page-content-wrapper">

      <nav class="navbar navbar-expand-lg navbar-light border-bottom" style="background-color: #e3f2fd;">

        <!-- Sidebar Toggle (Topbar) -->
        <button id="menu-toggle">
          <i class="fas fa-arrows-alt-h"></i>
        </button>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
            <img class="img-profile rounded-circle" src="Resources/img/usuario.png" width="40" height="40">
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <b>Jonathan Varon</b> 
              </a>
              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="Index.php"><b>Salir</b></a>
              </div>
            </li>
          </ul>
        </div>
      </nav>

      <!-- /Contenido -->
      <div id="content" class="container-fluid p-5">
        <h3 class="mt-4 text-center">Bienvenido</h3><br>

        <div class="card-deck">
          <div class="card w-100">
            <img src="Resources/img/prestamo.jpg" class="card-img-top" width="200" height="200">
            <div class="card-body">
              <h5 class="card-title text-center"><b>Préstamo</b></h5>
              <p class="card-text text-center">Préstamo de equipo portátil para estudiantes.</p>
            </div>
            <div class="card-footer text-center">
              <a href="prestamo.php" class="btn btn-info">Realizar</a>
            </div>
          </div>
          <div class="card w-100">
            <img src="Resources/img/consultarPrestamo.jpg" class="card-img-top" width="200" height="200">
            <div class="card-body">
              <h5 class="card-title text-center"><b>Consultar préstamo</b></h5>
              <p class="card-text text-center">Equipos portátiles en préstamo.</p>
            </div>
            <div class="card-footer text-center">
              <a href="consultarPrestamo.php" class="btn btn-info">Consultar</a>

            </div>
          </div>

        <!-- /Contenido -->
        </div>

        </form>

  <script src="Resources/jquery/jquery.min.js"></script>
  <script src="Resources/bootstrap/js/bootstrap.bundle.min.js"></script>

  <script>
    $("#menu-toggle").click(function(e) {
      e.preventDefault();
      $("#wrapper").toggleClass("toggled");
    });
  </script>

</body>

</html>
