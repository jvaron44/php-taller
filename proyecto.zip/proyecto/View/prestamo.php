

<!DOCTYPE html>
<html lang="en">

<head>

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="">
	<meta name="author" content="">
	<title>Préstamo</title>

	<link href="Resources/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link href="Resources/css/simple-sidebar.css" rel="stylesheet">
	<link href="Resources/fonts/simple-sidebar.css" rel="stylesheet">
	<link href="Resources/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
</head>

<body>
	<div class="d-flex" id="wrapper">

		<!-- Menú -->
		<div class="bg-light border-right" id="sidebar-wrapper">
			<div class="sidebar-heading text-center">U.Préstamo</div>
			<div class="list-group list-group-flush">
			  <a href="inicio.php" class="list-group-item list-group-item-action bg-light"><i class="fab fa-umbraco"></i>
					<b>Inicio</b>
				</a>
			  <a href="prestamo.php" class="list-group-item list-group-item-action bg-light"><i class="fas fa-laptop"></i>
                    <b>Préstamo</b>
                </a>
				<hr>
			</div>
		</div>
		<!-- /Menú-->

		<!-- Page Content -->
		<div id="page-content-wrapper">

			<nav class="navbar navbar-expand-lg navbar-light border-bottom" style="background-color: #e3f2fd;">

				<!-- Sidebar Toggle (Topbar) -->
				<button id="menu-toggle">
					<i class="fas fa-arrows-alt-h"></i>
				</button>

				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>

				<div class="collapse navbar-collapse" id="navbarSupportedContent">
					<ul class="navbar-nav ml-auto mt-2 mt-lg-0">
						<img class="img-profile rounded-circle" src="Resources/img/usuario.png" width="40" height="40">
						<li class="nav-item dropdown">
							<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
								<b>Jonathan Varon</b>
							</a>
							<div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
								<a class="dropdown-item" href="index.php"><b>Salir</b></a>
							</div>
						</li>
					</ul>
				</div>
			</nav>

			<!-- /Contenido -->
			<div class="container-fluid col-md-8 offset-md-2">
				<h3 class="mt-4 text-center">Nuevo préstamo
				</h3><br>
				<form action="?c=guardar" method="post">
					<div class="form-row">
						<div class="col-md-4">
							<label for="Fecha">Fecha/ hora de préstamo</label>
							<input type="hidden" name="txtID" value="<?php echo $alm->idPrestamo; ?>">
							<input type="datetime-local" class="form-control" name="txtFecha" value="<?php echo $alm->fecha; ?>">
						</div>
						<div class="col-md-3">
							<label for="Estado">Estado de prestamo</label>
							<input type="text" class="form-control" name="txtEstado" value="<?php echo $alm->estado; ?>">
						</div>
					</div>
					<div class="form-group"><br>
						<h5> Datos del estudiante</h5>
					</div>
					<div class="form-row">
						<div class="col-md-6">
							<label for="Nombres">Nombres</label>
							<div class="form-group d-flex">
								<input type="text" class="form-control" name="txtNombres" value="<?php echo $alm->nombres; ?>">
							</div>
						</div>
						<div class="col-md-6">
							<label for="Apellidos">Apellidos</label>
							<input type="text" class="form-control" name="txtApellidos" value="<?php echo $alm->apellidos; ?>">
						</div>
						<div class="col-md-6">
							<label for="Documento">Documento</label>
							<input type="text" class="form-control" name="txtDocumento" value="<?php echo $alm->documento; ?>">
						</div>
						<div class="col-md-6">
							<label for="Carnet">Nro carnet</label>
							<input type="text" class="form-control" name="txtCarnet" value="<?php echo $alm->carnet; ?>">
						</div>
					</div>
					<div class="form-group"><br>
						<h5> Datos del equipo</h5>
					</div>
					<div class="form-row">
						<div class="col-md-6">
							<label for="Equipo">Equipo</label>
							<div class="form-group d-flex">
								<input type="text" class="form-control" name="txtEquipo" value="<?php echo $alm->equipo; ?>">
							</div>
						</div>
					    <div class="col-md-6">
							<label for="Imei">IMEI-Equipo</label>
							<input type="text" class="form-control" name="txtImei" value="<?php echo $alm->imei; ?>">
						</div>
						</div>
						<div class="form-group">
							<label for="Descripción">Descripción</label>
							<textarea class="form-control" name="txtDescripcion" id="" rows="3" value="<?php echo $alm->descripcion; ?>"></textarea>
						</div>
						<div class="text-center">
						<input class="btn btn-info" type="submit" name="nytm" value="Guardar"></input>
						</div>
					</div>
					</form>
				</div>


			<!-- /Contenido -->
		</div>

     <!-- Footer -->
      <footer class="sticky-footer bg-white"><br>
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span></span>
          </div>
        </div>
      </footer>
      <!-- Fin Footer -->

		<script src="Resources/jquery/jquery.min.js"></script>
		<script src="Resources/bootstrap/js/bootstrap.bundle.min.js"></script>

		<script type="text/javascript">
			$(document).ready(function(){
				$('select').formSelect();
			})
		</script>

		<script>
			$("#menu-toggle").click(function(e) {
				e.preventDefault();
				$("#wrapper").toggleClass("toggled");
			});
		</script>

	</body>
	</html>
