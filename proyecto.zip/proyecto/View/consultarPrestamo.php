<!DOCTYPE html>
<html lang="en">

<head>

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="">
	<meta name="author" content="">
	<title>ConsultarPrestamo</title>
	<link href="Resources/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link href="Resources/css/simple-sidebar.css" rel="stylesheet">
	<link href="Resources/fonts/simple-sidebar.css" rel="stylesheet">
	<link href="Resources/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
	<!-- CSS personalizado --> 
    <link rel="stylesheet" href="Resources/main.css">  
      
    <!--datables CSS básico-->
    <link rel="stylesheet" type="text/css" href="Resources/datatables/datatables.min.css"/>
    <!--datables estilo bootstrap 4 CSS-->  
    <link rel="stylesheet"  type="text/css" href="Resources/datatables/DataTables-1.10.18/css/dataTables.bootstrap4.min.css">
           
</head>

<body>
	<div class="d-flex" id="wrapper">

		<!-- Menú -->
		<div class="bg-light border-right" id="sidebar-wrapper">
			<div class="sidebar-heading text-center">U.Préstamo</div>
			<div class="list-group list-group-flush">
			  <a href="inicio.php" class="list-group-item list-group-item-action bg-light"><i class="fab fa-umbraco"></i>
					<b>Inicio</b>
				</a>
			  <a href="prestamo.php" class="list-group-item list-group-item-action bg-light"><i class="fas fa-laptop"></i>
                    <b>Préstamo</b>
                </a>
				<hr>
			</div>
		</div>
		<!-- /Menú-->

		<!-- Page Content -->
		<div id="page-content-wrapper">

			<nav class="navbar navbar-expand-lg navbar-light border-bottom" style="background-color: #e3f2fd;">

				<!-- Sidebar Toggle (Topbar) -->
				<button id="menu-toggle">
					<i class="fas fa-arrows-alt-h"></i>
				</button>

				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>

				<div class="collapse navbar-collapse" id="navbarSupportedContent">
					<ul class="navbar-nav ml-auto mt-2 mt-lg-0">
						<img class="img-profile rounded-circle" src="Resources/img/usuario.png" width="40" height="40">
						<li class="nav-item dropdown">
							<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
								<b>Jonathan Varon</b>
							</a>
							<div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
								<a class="dropdown-item" href="index.php"><b>Salir</b></a>
							</div>
						</li>
					</ul>
				</div>
			</nav>

			<!-- /Contenido -->
			<div class="container-fluid col-md-12 offset-md-2">
				<h3 class="mt-4 text-center">Consultar Préstamo</h3><br>

				<div class="col-lg-12">
                    <div class="table-responsive">
                    <div class="text-center">
                        <a href="?c=nuevo" class="btn btn-info">Nuevo</a>
                        </div><br>       
                        <table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
                        <thead>
                            <tr>
                                <th class="text-center">Nombres</th>
                                <th class="text-center">Apellidos</th>                             
                                <th class="text-center">Documento</th>
                                <th class="text-center">NroCarnet</th>
                                <th class="text-center">Equipo</th>
                                <th class="text-center">IMEI</th>
                                <th class="text-center">Descripción</th>
                                <th class="text-center">Fecha</th>
                                <th class="text-center">Estado</th>
                                <th class="text-center">Editar</th>  
                            </tr>
                        </thead>
                        <tbody>
                        <?php  foreach ($this->MODEL->listar() as $k) : ?>
                            <tr>
                                <td><?php echo $k->nombres; ?></td>
                                <td><?php echo $k->apellidos; ?></td>
                                <td><?php echo $k->documento; ?></td>
                                <td><?php echo $k->carnet; ?></td>
                                <td><?php echo $k->equipo; ?></td>
                                <td><?php echo $k->imei; ?></td>
                                <td><?php echo $k->descripcion; ?></td>
                                <td><?php echo $k->fecha; ?></td>
                                <td><?php echo $k->estado; ?></td>    
                                <td>
                                  <div class="d-flex">
                                    <a class="btn btn-info" href="?c=nuevo&id=<?php echo $k->idPrestamo; ?>"><i class="far fa-edit"></i></a>
                                    <a class="btn btn-danger" href="?c=eliminar&id=<?php echo $k->idPrestamo; ?>"><i class="far fa-trash-alt"></i></a>
                                </div>
                                </td>
                            </tr> 
                        <?php endforeach; ?>                   
                        </tbody>    
                       </table>                  
                    </div>
                </div>



					</div>
				</div>

			<!-- /Contenido -->
		</div>

     <!-- Footer -->
      <footer class="sticky-footer bg-white"><br>
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span></span>
          </div>
        </div>
      </footer>
      <!-- Fin Footer -->

		<script src="Resources/jquery/jquery.min.js"></script>
		<script src="Resources/bootstrap/js/bootstrap.bundle.min.js"></script>

		<script>
			$("#menu-toggle").click(function(e) {
				e.preventDefault();
				$("#wrapper").toggleClass("toggled");
			});
		</script>

   <!-- datatables JS -->
    <script type="text/javascript" src="Resources/datatables/datatables.min.js"></script>    
     
    <!-- para usar botones en datatables JS -->  
    <script src="Resources/datatables/Buttons-1.5.6/js/dataTables.buttons.min.js"></script>  
    <script src="Resources/datatables/JSZip-2.5.0/jszip.min.js"></script>    
    <script src="Resources/datatables/pdfmake-0.1.36/pdfmake.min.js"></script>    
    <script src="Resources/datatables/pdfmake-0.1.36/vfs_fonts.js"></script>
    <script src="Resources/datatables/Buttons-1.5.6/js/buttons.html5.min.js"></script>
     
    <!-- código JS propìo-->    
    <script type="text/javascript" src="Resources/main.js"></script>  

	</body>
	</html>
