<?php
class conexion{
  public static function conectar(){
  $x = new PDO("mysql: host=localhost; dbname=proyectophp; charset=utf8","root","123");
  $x->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  return $x;
  }
}
?>
