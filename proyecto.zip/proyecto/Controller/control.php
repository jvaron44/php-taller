<?php
  include_once 'Model/prestamo.php';
class control{

  public $MODEL;

  public function __construct(){
    $this->MODEL = new prestamo();
  }

  public function index(){
    include_once 'View/consultarPrestamo.php';
  }

  public function nuevo(){
    $alm = new prestamo();
    if(isset($_REQUEST['id'])){
      $alm= $this->MODEL->cargarID($_REQUEST['id']);

    }
    include_once 'View/prestamo.php';
  }

  public function guardar(){
      $alm = new prestamo();
      $alm->idPrestamo = $_POST['txtID'];
      $alm->nombres = $_POST['txtNombres']; 
      $alm->apellidos = $_POST['txtApellidos'];
      $alm->documento = $_POST['txtDocumento'];
      $alm->carnet = $_POST['txtCarnet'];
      $alm->equipo = $_POST['txtEquipo'];
      $alm->imei = $_POST['txtImei'];
      $alm->descripcion = $_POST['txtDescripcion'];
      $alm->fecha = $_POST['txtFecha'];
      $alm->estado = $_POST['txtEstado'];

      $alm->idPrestamo > 0 ? $this->MODEL->actualizarDatos($alm) : $this->MODEL->registrar($alm);

      header("Location: index.php");
  }

  public function eliminar(){
    $this->MODEL->delete($_REQUEST['id']);
    header("Location: index.php");

  }

}

 ?>
